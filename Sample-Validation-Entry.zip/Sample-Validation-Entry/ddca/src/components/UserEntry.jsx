import React, { Component } from 'react';
import Swal from 'sweetalert2';

const  apiUrl =  "http://localhost:50976/api/"
class UserEntry extends Component {   
    constructor(props) {
        super(props);
        
        this.onHandleTelephoneChange = this.onHandleTelephoneChange.bind(this);  
        this.onHandleBasicSalaryChange = this.onHandleBasicSalaryChange.bind(this); 
        this.state = {
            firstName: '',
            lastName:'',
            telephone: '',
            basicSalary:'',
            regexpTelephone : /^[0-9\b+()-]+$/,
            regexpAmount : /^[0-9\b.,]+$/
        }   
    }
     
    onHandleTelephoneChange = e => {
        let telephone = e.target.value;
        if (telephone === '' || this.state.regexpTelephone.test(telephone)) {
            this.setState({ [e.target.name]: telephone })
        }
    };

    onHandleBasicSalaryChange = e => {
        let basicSalary = e.target.value;
        if (basicSalary === '' || this.state.regexpAmount.test(basicSalary)) {
            this.setState({ [e.target.name]: basicSalary })
        }
    };


    handleSubmit =(e) =>{    

        e.preventDefault();
       // creates entity
       //"x-ddcaapi-host": "ddcadb.p.ddcaapi.com",
       //"x-ddcaapi-key": "apikey",     
       fetch(apiUrl + "AddUserRecord", {
            "method": "POST",
            "headers": {
                "content-type": "application/json",
                "accept": "application/json"
            },
            "body": JSON.stringify({
                FirstName: this.state.firstName,
                LastName: this.state.lastName,
                Telephone: this.state.telephone, 
                basicSalary: this.state.basicSalary.replace(',',''),     
            })         
        })
        .then(response => response.json())
        .then(response => {
            console.log(response)
            Swal.fire(response.toString());
        })
        .catch(err => {
            console.log(err);
            Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: err.toString(),
            })  
            return;    
        });
        // Initialize state fields
        this.setState = {
            firstName: '',
            lastName:'',
            telephone: '',
            basicSalary:'',          
        }    
    }

    render() {
        return (
            < >
            <div  className="text-center" >
                <div className="mt-1">      
                    <label>Fist Name: </label>
                    <input type="text" 
                        name="fistName"
                        placeholder="First Name"
                        value={this.state.firstName}
                        onChange={(e) => this.setState({ firstName: e.target.value })}                       
                    />
                </div>
                <div className="mt-1">      
                    <label>Last Name: </label>
                    <input type="text" 
                        name="lastName"
                        placeholder="Last Name"
                        value={this.state.lastName}
                        onChange={(e) => this.setState({ lastName: e.target.value })}                       
                    />
                </div>
                <div  className="mt-1">
                    < label >Telephone: </ label >
                    < input
                        type="tel" name="telephone" placeholder="Number"
                        value={this.state.telephone}
                        onChange={this.onHandleTelephoneChange}
                    />
                </div>
                <div className="mt-1">
                    < label >Basic Salary: </ label >
                    < input
                        type="amt" name="basicSalary" placeholder="Basic Amount"
                        value={this.state.basicSalary}
                        onChange={this.onHandleBasicSalaryChange}
                    />
                </div>
                <div className="form-group">
                    <span className="mr-2">
                        <button  className="btn btn-primary" onClick={this.handleSubmit}>Save</button>      
                    </span>
                    <span  className="mr-2">
                    <button  className="btn btn-primary" onClick={this.handleClick}>Cancel</button>          
                    </span>
                </div> 
            </div>           
            </>
        );
    }
}
export default UserEntry;











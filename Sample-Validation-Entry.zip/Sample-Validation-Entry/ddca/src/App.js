import React from 'react';
import {useObserver} from 'mobx-react'
import UserEntry from './components/UserEntry'
import "bootstrap/dist/css/bootstrap.min.css"
import './App.css';

//const StoreContext= React.createContext();

const DDCAHeader = () =>{
  //const store =React.useContext(StoreContext);
  return useObserver(() => (
  <h1 className="text-center">User Entry</h1>
  ))
}



const DDCAForm =()=>{
  return(
    <form>
       <div>
        <UserEntry/>
      </div>
    </form>
  );
}


function App() {
  return (
    <>
      <DDCAHeader />
      <DDCAForm />
    </>
  );
}

export default App;

import React from 'react';
import {useObserver} from 'mobx-react'
import CustomerEntry from './components/CustomerEntry'
import "bootstrap/dist/css/bootstrap.min.css"
import './App.css';

//const StoreContext= React.createContext();

const DDCAHeader = () =>{
  //const store =React.useContext(StoreContext);
  return useObserver(() => (
  <h1 className="text-center">Customer Entry!</h1>
  ))
}



const DDCAForm =()=>{
  return(
    <form>
       <div>
        <CustomerEntry/>
      </div>
    </form>
  );
}


function App() {
  return (
    <>
      <DDCAHeader />
      <DDCAForm />
    </>
  );
}

export default App;

﻿using WebApplication1.Models;
using System;
using System.Web.Http;
using System.Net.Http;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Net;
using System.Web.Http.Cors;
using HttpContext = System.Web.HttpContext;
using System.Web.Http.Description;
using System.Text;

namespace WebApplication1.Controllers
{
    // A Customized API Methods
    [EnableCors(origins: "*", headers: "*", methods: "*")]
    public class ItemsController : ApiController
    {
         private SwaggerIntegrationContext db = new SwaggerIntegrationContext();


        [ResponseType(typeof(Items))]
        [Route("api/AddUserRecord")]
        [HttpPost]
        public string AddUserRecord(User user)
        {
            try
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendLine("INSERT INTO Users");
                sb.AppendLine("(FirstName");
                sb.AppendLine(",LastName");
                sb.AppendLine(",EmailAddress");
                sb.AppendLine(",BasicSalary)");
                sb.AppendLine("VALUES(");
                sb.AppendLine("'"+ user.FirstName+ "'");
                sb.AppendLine(",'" + user.LastName + "'");
                sb.AppendLine(",'" + user.Telephone+ "'");
                sb.AppendLine("," + user.BasicSalary);
                sb.AppendLine(")");

                DataTable table = new DataTable();
                using (var conn = new SqlConnection(ConfigurationManager.ConnectionStrings["UserDB"].ConnectionString))
                using (var cmd = new SqlCommand(sb.ToString(), conn))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                    return "Added Successfully!";
                }
            }
            catch (Exception ex)
            {
                return "Failure to Add!";
            }
        } 
    }
}

using System.Web.Http;
using WebActivatorEx;
using WebApplication1;
using Swashbuckle.Application;

[assembly: PreApplicationStartMethod(typeof(SwaggerConfig), "Register")]

namespace WebApplication1
{
    public class SwaggerConfig
    {
        public static void Register()
        {
            var thisAssembly = typeof(SwaggerConfig).Assembly;

            GlobalConfiguration.Configuration
                .EnableSwagger(c =>
                {
                    c.SingleApiVersion("v1", "Documentation Using Swagger UI<br>Author by: Algem Mojedo</br><br>Date Created: 12/21/2020</br>");                  
                })
                .EnableSwaggerUi(c =>
                {
                    c.DocumentTitle("Items Swagger UI");
         
                });
        }
    }
}
